from main_menu import menu

default_car_folder = "C:/kaise/Desktop/LapSim/car_modells"
default_track_folder = "C:/Users/kaise/Desktop/LapSim/tracks"

icon_path = "C:/Users/kaise/Desktop/GFR Software/icon/logo_4SY_icon.ico"
top_path= "C:/Users/kaise/Desktop/GFR Software/picture/top_1.png"
bottom_path="C:/Users/kaise/Desktop/GFR Software/picture/bottom_1.png"


print(tracks)

test = menu(icon_path,top_path,bottom_path)
menu.gui_engine()

